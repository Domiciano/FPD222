class Task{

    constructor(task, state){
        this.task = task;
        this.state = state;
    }

    

}