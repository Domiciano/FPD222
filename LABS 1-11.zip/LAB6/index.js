const contenedorTareas = document.getElementById('contenedorTareas');

let precio = 9900;


if(precio >= 100000){
    let total = precio * 0.8;
    contenedorTareas.innerHTML = `<h1>Su compra sale en $ ${total}</h1>`;
}else{
    contenedorTareas.innerHTML = `<h3>Su compra sale en $ ${precio}</h3>`;
}

//Lo que ya estaba + lo nuevo
contenedorTareas.innerHTML += ". Gracias por su compra";

//Vamos a crear 2 contactos
let nombre1 = 'Daniel Zapata';
let numero1 = '762358234';

let nombre2 = 'Sebastian Romero';
let numero2 = '12342423';

contenedorTareas.innerHTML += `<div class="contact"> <b>${nombre1}</b> <p>${numero1}</p> </div>`; 

contenedorTareas.innerHTML += `<div class="contact"> <b>${nombre2}</b> <p>${numero2}</p> </div>`; 





