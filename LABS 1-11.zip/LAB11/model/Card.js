class Card{

    constructor(id, name, img, price){
        this.id = id;
        this.name = name;
        this.img = img;
        this.price = price;
        this.liked = false;
    }

    render(container){
        let card = document.createElement('div');
        card.classList.add('card');
        
        let html=`<img src="${this.img}" width="128px">
                        <div class="content">
                            <div>${this.name}</div>
                            <b>$ ${this.price}</b>
                            <a href="product.html?id=${this.id}">Comprar</a>
                            <button id="like${this.id}" class="unliked">LIKE</product>
                        </div>`;
        
        card.innerHTML += html;
        container.appendChild(card);

        let likeBtn = document.getElementById(`like${this.id}`);
        likeBtn.addEventListener('click', this.addLike.bind(this) );
    }

    addLike(){
        let likeBtn = document.getElementById(`like${this.id}`);
        this.liked = !this.liked;
        if(this.liked){
            likeBtn.classList.remove("unliked");
            likeBtn.classList.add("liked");
        }else{
            likeBtn.classList.remove("liked");
            likeBtn.classList.add("unliked");
        }
    }



}