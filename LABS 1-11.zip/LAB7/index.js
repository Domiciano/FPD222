const contenedor = document.getElementById('contenedor');
//Parentesis -> Entrada
//Return -> Salida

//Creacion de la funcion
function createTitle(numero){
    let text = `Este es mi titulo ${numero}`;
    let html = `<h1>${text}</h1>`;
    return html;
}

function createPost(name, message, imageURL){
    let img = `<img src="${imageURL}">`;
    let h3 = `<h3>${name}</h3>`;
    let p = `<p>${message}</p>`;
    return `<div class="card">${img} ${h3} ${p}</div>`;
}

//Uso de la funcion
for(let i=1 ; i<=826 ; i++){
    let content = createPost(
        `Character ${i}`,
        `Esta es mi publicacion numero ${i}`,
        `https://rickandmortyapi.com/api/character/avatar/${i}.jpeg`
    );
    contenedor.innerHTML += content;
}