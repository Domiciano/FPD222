const createPostBox = document.getElementById('createPostBox');
const backLayer = document.getElementById('backLayer');
const editorWindow = document.getElementById('editorWindow');
const closeBtn = document.getElementById('closeBtn');

function showEditor(e){
    e.preventDefault();
    //Desocultar el div de publicacion
    backLayer.classList.remove('hidden');
    editorWindow.classList.remove('hidden');
    //backLayer.classList.add('hidden');
}

function closeWindow(e){
    e.preventDefault();
    //Desocultar el div de publicacion
    backLayer.classList.add('hidden');
    editorWindow.classList.ad('hidden');
}

createPostBox.addEventListener('click', showEditor);
closeBtn.addEventListener('click', closeWindow)