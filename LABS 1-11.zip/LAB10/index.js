const container = document.getElementById('container');

let minions = {
    image: "https://cinemedios.com/wp-content/uploads/2013/06/el-macho.png",
    title: "Mi villano favorito 2",
    rating: 4,
    description: "Esta es la pelicula donde sale el sombrero de nachos",
    isSaved: true,
    PG: 13
};

function showCard(movie){
    let html = `<div class="card">
                    <img src="${movie.image}">
                    <h3>${movie.title}</h3>
                    <span>${movie.description}</span>
                </div>`;
    return html;
}

let card = showCard(minions);

container.innerHTML += card;